package com.example.a8bmijudgment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView BMI = (TextView)findViewById(R.id.textView);
        TextView confirm = (TextView)findViewById(R.id.textView3);

        Intent intent = getIntent();
        float height_EXTRA = intent.getFloatExtra("height_EXTRA",0);
        float weight_EXTRA = intent.getFloatExtra("weight_EXTRA",0);
        float bmi = weight_EXTRA/((height_EXTRA/100)*(height_EXTRA/100));
        DecimalFormat nf = new DecimalFormat("0.0");
        BMI.setText("BMI:"+nf.format(bmi));
        if( bmi<=24 && bmi>=18.5)
            confirm.setText("BMI normal");
        else
            confirm.setText("BMI abnormal");


    }
    public void back(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}